export class customer {
    custname;
    email;     
    address;
    phonenumber;
    credit_limit;
}