import { Component, OnInit } from '@angular/core';
import { CustomersService } from '../customers.service';
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  customers:any;

  constructor(private customer:CustomersService) { }

  ngOnInit() {
    this.customer.getAllCustomers().subscribe(r=>this.customers=r);
  }

  getAvg(){
    var temp = 0;
    var number = this.customers.length;
    for(var i = 0; i < number ; i++)
        temp += this.customers[i].credit_limit;

    return (temp/number);
  }

  getMax(){
    var max = 0;
    var number = this.customers.length;
    for(var i = 0; i < number ; i++)
        if( this.customers[i].credit_limit > max)
            max = this.customers[i].credit_limit;

    return max;
  }

}
