import { Injectable } from '@angular/core';
import { Book } from '../models/book.model';

@Injectable({providedIn:'root'})
export class BookHubService {

  books:Book[]=[];
  count:number=101;
  constructor() { 
    this.books = [
      { id: 11, title: ".NET Framework", author: "Ravi Tambade", category: "Programming Language", availability: true },
      { id: 1, title: "English Grammer", author: "Alieen", category: "Literature", availability: true },
      { id: 13, title: "Fire & Blood", author: "RR Martin", category: "Fiction", availability: false },
      { id: 17, title: "Harry Potter", author: "JK Rowling", category: "Fiction", availability: true },
      { id: 12, title: "Java", author: "Ravi Tambade", category: "Programming Language", availability: true }
    ];
  }

  public getAllBooks():Book[]{

    
    return this.books;
  }

  public getBook(id:number):Book{
    let book:Book;
    this.books.forEach(b => {
      if(b.id === id){
        book = b;
        return book;
      }
    });
    return book;
  }

  public getAvailableBooks():Book[]{
    let availableBooks:Book[]=[];
    this.books.forEach(b => {
      if(b.availability === true){
        availableBooks.push(b);
      }
    });
    return availableBooks;
  }

  public addBook(b:Book):boolean{
    var status:boolean=false;
    b.id=this.count++;
    this.books.push(b);
    status=true;
    return status;
  }

  public updateBook(b:Book):boolean{
    var status:boolean = false;
    this.books.forEach(book => {
      if(b.id === book.id){
        book.title = b.title;
        book.author = b.author;
        book.category = b.category;
        book.availability = b.availability;
        status=true;
      }
    });
    return status;
  }
}
