import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  users:User[]=[];

  constructor() { 

    this.users.push({email:"aa@g.com",password:"12345"});
    this.users.push({  email: "bb@g.com",  password: "12345" });
    this.users.push({  email: "cc@g.com",  password: "12345" });
    this.users.push({  email: "dd@g.com",  password: "12345" });

  }

  public getAllUsers():User[]{
    return this.users;
  }

  public authenticate(user:User):boolean{
    console.log(this.users);
    let status:boolean=false;
    console.log("user--->"+user.email)
    this.users.forEach(u => {
      console.log(user.email);
      if( u.email === user.email && user.password === u.password){
        console.log(user.email);
        status=true;
      }
    });
    return status;
  }
}
