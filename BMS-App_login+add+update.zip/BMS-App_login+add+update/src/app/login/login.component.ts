import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { User } from '../models/user.model';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  tempUser:User={email:"",password:""};
  isLogin:boolean=localStorage.getItem("isLogin")=="true";
  tried:boolean=false;
  msg:string="";
  constructor(private svc:AuthenticationService) { }

  ngOnInit() {
    if (this.isLogin) {
      this.msg = "You Are Already Logged In.";
    }
  }

  onSignInClick(){
    console.log(this.tempUser);
    this.tried = true;
    if(this.svc.authenticate(this.tempUser)){
      localStorage.setItem("isLogin","true");
      this.isLogin=true;
      this.msg="You are Now Logged In!!";
    }
    else{
      this.msg = "Email/Password Incorrect.";
    }
    
  }



}
