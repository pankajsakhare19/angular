export class Book {
    id:number;
    title:string;
    author:string;
    category: string;
    availability:boolean;

    public constructor(id:number, title:string, author:string, category:string, availability:boolean) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.category = category;
        this.availability = availability;
    }
}
