import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from "@angular/router";
import { FormsModule } from "@angular/forms";

import { AppComponent } from './app.component';
import { ListComponent } from './list/list.component';
import { DetailsComponent } from './list/details/details.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ShoppingComponent } from './shopping/shopping.component';
import { InsertBookComponent } from './insert-book/insert-book.component';
import { UpdateBookComponent } from './list/update-book/update-book.component';

const routes:Routes=[
  {path:"list",component:ListComponent,children:[
    {path:":id",component:DetailsComponent},
    {path:"update/:id",component:UpdateBookComponent}
  ]},
  {path:"login",component:LoginComponent},
  {path:"register",component:RegisterComponent},
  {path:"insert", component:InsertBookComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    DetailsComponent,
    LoginComponent,
    RegisterComponent,
    ShoppingComponent,
    InsertBookComponent,
    UpdateBookComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
