import { Component, OnInit, Input } from '@angular/core';

import { BookHubService } from '../services/book-hub.service';
import { Book } from '../models/book.model';
@Component({
  selector: 'app-insert-book',
  templateUrl: './insert-book.component.html',
  styleUrls: ['./insert-book.component.css']
})
export class InsertBookComponent implements OnInit {

  tempBook: Book = { id: 0, title:"",author: "", category: "", availability: false};
  avail:string="";
  constructor(public svc:BookHubService) { }

  ngOnInit() {
    console.log(this.tempBook);
    
  }

  onAddClick(){
    console.log(this.tempBook);
    this.tempBook.availability=(this.avail==="true");
    this.svc.addBook(this.tempBook);
    console.log(this.tempBook);
  }

}
