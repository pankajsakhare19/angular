import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'BMSApp';
  isLogin:string;

  constructor(){

  }

  ngOnInit(){
    if(localStorage.getItem("isLogin") === undefined){
      localStorage.setItem("isLogin","false");
    }
    this.isLogin = localStorage.getItem("isLogin");
  }
}
