import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';

import { Book } from 'src/app/models/book.model';
import { BookHubService } from 'src/app/services/book-hub.service';


@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  book:Book;

  constructor(private svc:BookHubService,
              private route:ActivatedRoute) { }

  ngOnInit() {
    const id = +this.route.snapshot.params['id'];
    console.log(id);
    this.book=this.svc.getBook(id);
    this.route.params.subscribe(
      (par: Params)=>{
        this.book = this.svc.getBook(+par['id']);
      }
    );
    console.log(this.book);
  }

}
