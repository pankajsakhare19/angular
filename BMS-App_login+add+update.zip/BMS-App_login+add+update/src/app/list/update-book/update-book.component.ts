import { Component, OnInit } from '@angular/core';
import { BookHubService } from 'src/app/services/book-hub.service';
import {Book} from '../../models/book.model';
import { ActivatedRoute, Params } from '@angular/router';
@Component({
  selector: 'app-update-book',
  templateUrl: './update-book.component.html',
  styleUrls: ['./update-book.component.css']
})
export class UpdateBookComponent implements OnInit {

  tempBook:Book;

  avail:string="";

  constructor(private svc:BookHubService,
              private route:ActivatedRoute) { 
    

  }

  ngOnInit() {
    const id = +this.route.snapshot.params['id'];
    this.tempBook = this.svc.getBook(id);
    this.route.params.subscribe(
      (par: Params) => {
        this.tempBook = this.svc.getBook(+par['id']);
      }
    );
  }

  onUpdateClick(){
    console.log(this.tempBook);
    this.tempBook.availability = (this.avail === "true");
    console.log(this.tempBook);
    this.svc.updateBook(this.tempBook);
  }

}
