import { Component, OnInit } from '@angular/core';
import { Book } from '../models/book.model';
import { BookHubService } from '../services/book-hub.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  books:Book[]=[];

  constructor(private svc:BookHubService) { }

  ngOnInit() {
    this.books=this.svc.getAllBooks();
    console.log(this.books);
  }

}
