import { Component, OnInit } from '@angular/core';
import { UserHubService } from '../user-hub.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userName: string = '';
  password: string = '';
  login: boolean = false;
  msg: string = '';
  constructor(public userHubService: UserHubService) { }

  ngOnInit() {
  }
  onLogin() {
    console.log(this.userName + this.password);
    this.login = this.userHubService.authenticate({ userName: this.userName, password: this.password });
    console.log(this.login);
    if (this.login){
      console.log("success");
      this.msg = "Login Successful";
    }
    else{
      console.log("failed");
      this.msg = "Login Failed";
    }
  
  }
}
