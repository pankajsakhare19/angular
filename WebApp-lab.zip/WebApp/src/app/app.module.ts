import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { UserHubService } from './user-hub.service';
import { from } from 'rxjs';
import { UserComponent } from './user/user.component';
import { FormsModule } from '@angular/forms';

const appRoutes: Routes = [{ path: 'login', component: LoginComponent },
{ path: 'register', component: RegisterComponent },
{ path: 'changepassword', component: ChangePasswordComponent },
{ path: 'users', component: UserComponent }];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ChangePasswordComponent,
    UserComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [UserHubService],
  bootstrap: [AppComponent]
})
export class AppModule { }
