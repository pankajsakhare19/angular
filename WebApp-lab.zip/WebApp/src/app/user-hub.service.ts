import { Injectable } from '@angular/core';

@Injectable()
export class UserHubService {
  users: any = [
    { "UserID": 101, "UserName": "shikhar", "Password": "12345" },
    { "UserID": 102, "UserName": "vishal", "Password": "12345" },
    { "UserID": 103, "UserName": "pankaj", "Password": "12345" }
  ];

  count=4;
  status: Boolean;

  constructor() {  }
  public getUsers(): any {
    return this.users;
  }
  public authenticate(u: any): any {
    console.log(u);

    this.status = false;
    this.users.forEach(user=> {
      if (u.userName == user.UserName && u.password == user.Password)
        this.status = true;
    });
    
    console.log("status : " + this.status);

    return this.status;
  }
  
  public addUser(u:any): any {
    console.log(u);
    u.UserID = this.count++;
    this.users.push(u);
    return "Registered Successfully";
  }
  public changePassword(u:any): any {
    console.log(u);
    this.users.push(u);
    return "Password Changed";
  }

}
