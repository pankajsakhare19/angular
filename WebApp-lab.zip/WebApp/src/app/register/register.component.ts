import { Component, OnInit } from '@angular/core';
import { UserHubService } from '../user-hub.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  username: string = "";
  password: string = "";
  msg: string = "";
  constructor(public svc: UserHubService) { }

  ngOnInit() {
  }
  onRegister() {
    console.log(this.username,this.password);
   this.msg= this.svc.addUser( { "UserID": 0, "UserName": this.username, "Password": this.password},);
  }

}
