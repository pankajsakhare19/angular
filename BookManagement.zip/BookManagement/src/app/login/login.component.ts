import { Component, OnInit } from '@angular/core';
import { UserHubService } from "../user-hub.service";
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName: string = '';
  password: string = '';
  login: boolean = false;
  msg: string = '';

  constructor(public userHubService: UserHubService) { }

  ngOnInit() {
  }

  onLogin(){
    var obj={
      UserName: this.userName,
      Password: this.password
    };
    this.login= this.userHubService.authenticate(obj);
    if(this.login){
      this.msg="Login Successfully";
    }
    else{
      this.msg="Login Failed";
    }
  }

}
