import { Injectable } from '@angular/core';

@Injectable()
// @Injectable({
//   providedIn: 'root'
// })
export class UserHubService {


  users:any = [
    { "UserID": 101, "UserName": "pankaj", "Password":"12345" },
    {"UserID":102, "UserName": "akash", "Password":"12345"},
    {"UserID":103, "UserName": "shikhar", "Password":"12345"}
  ];

  count=104;
  status:Boolean;

  constructor() { }

  public getUsers():any{
    return this.users;
  }

  public authenticate(u:any):any{
    this.status=false;
    console.log(u.UserName + u.Password)
    this.users.forEach(user=>{
      if(u.UserName==user.UserName && u.Password==user.Password)
      this.status=true;
    });
    return this.status;
  }

  public addUser(u:any):any{
    u.UserID = this.count++;
    this.users.push(u);
    return "Registered Successfully";
  }

  public changePassword(u:any):any{
    console.log("in user-hub"+u.UserName + " "+ u.Password)
    this.status=false;
    this.users.forEach(user=>{
      if(u.UserName == user.UserName){
        console.log(u.UserName+" "+user.UserName);
        user.Password = u.Password;
        this.status=true;
      }
    });
    return this.status;
  }
}
