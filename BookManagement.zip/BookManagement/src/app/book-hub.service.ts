import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookHubService {

  books:any=[
    {"BookID":11, "BookName":"Java", "Author":"Mrs.Madhura"},
    {"BookID":12, "BookName":"DotNet", "Author":"Mr.Ravi"},
    {"BookID":13, "BookName":"Cpp", "Author":"Mr.Praful"},
    {"BookID":14, "BookName":"MeanStack", "Author":"Mr.Ganesh"}

  ];

  constructor() { }

  public getBooks():any{
    return this.books;
  }
}
