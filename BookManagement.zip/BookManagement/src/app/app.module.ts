import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './user/user.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { UserHubService } from "./user-hub.service";
import { BookHubService } from "./book-hub.service";
import { FormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { BookComponent } from './book/book.component';

const appRoutes: Routes = [{path: 'login', component: LoginComponent},
{path: 'register', component: RegisterComponent},
{path: 'users', component: UserComponent},
{path: 'changepassword', component: ChangePasswordComponent},
{path: 'books', component: BookComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    UserComponent,
    ChangePasswordComponent,
    BookComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [UserHubService,BookHubService],
  bootstrap: [AppComponent]
})
export class AppModule { }
