import { Component, OnInit } from '@angular/core';
import { UserHubService } from "../user-hub.service";
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  UserName: string='';
  Password: string='';
  confirmPass: string='';
  update:boolean=false;
  msg: string='';
  constructor(public userHubService: UserHubService) { }

  ngOnInit() {
  }

  onUpdate(){
    if(this.Password==this.confirmPass)
    {
      console.log(this.UserName+" "+ this.Password)
      var obj={
        UserName:this.UserName,
        Password:this.Password
      };
      console.log("in comp"+obj.UserName + " "+ obj.Password)
      this.update=this.userHubService.changePassword(obj);
      if(this.update){
        this.msg="Password Updated Successfully"
      }
      else{
        this.msg="Password Not Updated"
      }
    }
    else{
      this.msg="Please Enter Same Password"
    }
  }

}
