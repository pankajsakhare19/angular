import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plagarism-report',
  templateUrl: './plagarism-report.component.html',
  styleUrls: ['./plagarism-report.component.css']
})
export class PlagarismReportComponent implements OnInit {
 
  
  constructor() { }

  ngOnInit() {
  }
 
}
