import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
email:any=''
password:any=''
msg:any=''
  constructor(private router:Router) { }

  ngOnInit() {
  }
  onLogin():any{
    if(this.email=="durga@" && this.password=="123")
    {
      console.log("success");
      console.log(this.msg);
      alert("login successful");
      this.router.navigate(['/List']);

    }
    else{
      alert("invalid");
    }
  }
  onRemove():any{
  
 localStorage.removeItem(this.email);


  }

}
