import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
email:any=''
Password:any=''
Name:any=''
users:any=[]
  constructor() { }

  ngOnInit() {
  }
  onSave():any{
    
    let user={
      email:this.email,
      Password:this.Password,
      Name:this.Name
    }
    let em=this.email;
    this.users.push(user);
    localStorage.setItem("user",JSON.stringify(this.users));
    
    console.log("added");
  }


}
