import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
users:any=[]
email:any=''
  constructor() { }

  ngOnInit() {
    
   
  }
  onList():any{
  
   
    this.users=JSON.parse(localStorage.getItem('user'));
    console.log(this.users);
    
  }
  
}
 
  


