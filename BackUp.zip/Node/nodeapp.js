http    =   require('http');
url     =   require('url');
query   =   require("querystring");
fs      =   require('fs');
emi     =   require('./emi');

function process_request(req,resp){
   u=url.parse(req.url);
   console.log(u);
   resp.writeHead(200,{'content-type':'text/html'});
   switch(u.pathname){
     case '/':
	    fs.readFile("./index.html",function(err,data){
		     if(err)
			     resp.write("Some error");
			 else
			     resp.write(data);			    
			 resp.end();
		});
		break;
	case '/process':
	       str="";
		   req.on("data",function(d){
			   str+=d;
		   });
		   req.on("end",function(){
				response = "EMI is ";
                result=query.parse(str);
                amount = result.amount;
				duration = result.duration;
				if(duration!=0 || amount!=0)
					response += emi.calculate(result.amount,result.duration);
				else	
					response += "Invalid Amount or Month Duration"

				console.log(response);
                resp.end(response);
		   });		
	     break;
   }
}
server=http.createServer(process_request);
server.listen(3000);
console.log("server is running at port 3000");